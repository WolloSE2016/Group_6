package com.mycompany.groupmember;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GroupMember {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        // Group information
        String section = "Section A";
        String groupName = "Group_6";
        
        // Member data (RollNo, FirstName, LastName, IDno)
        String[][] members = {
            {"1", "Alemenew", "Dubie", "WOUR/0181/16"},
            {"2", "Temesgen", "Taddesse", "WOUR/1879/16"},
            {"3", "Abyssinia", "Yirgalem", "WOUR/0102/16"},
            {"4", "Kelem", "Zhekale", "WOUR/1140/16"},
            {"5", "Ferhan", "Mohammed", "WOUR/0791/16"},
            {"6", "Endris", "Zeynu", "WOUR/0688/16"}
        };

        // Create main frame with gradient background
        JFrame frame = new JFrame("Group Members Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 550); // Slightly taller to accommodate university info
        frame.setLayout(new BorderLayout(10, 10));
        frame.setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(173, 216, 230); // Light blue
                Color color2 = new Color(255, 255, 255); // White
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        });

        // Create university info panel
        JPanel universityPanel = new JPanel(new GridLayout(1, 1));
        universityPanel.setOpaque(false);
        universityPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel universityLabel = new JLabel(
            "<html><center>WOLLO UNIVERSITY KIOT<br>" +
            "INFORMATICS COLLEGE<br>" +
            "DEPARTMENT OF SOFTWARE ENGINEERING<br>" +
            "Second Year Second Semester</center></html>", 
            JLabel.CENTER
        );
        universityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        universityLabel.setForeground(new Color(0, 0, 139)); // Dark blue
        universityPanel.add(universityLabel);

        // Create header panel with color
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("GROUP MEMBERS LIST");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 0, 139)); // Dark blue
        headerPanel.add(titleLabel);

        // Create info panel with color
        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        infoPanel.setOpaque(false);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 50, 5, 50));
        
        JLabel sectionLabel = new JLabel("Section: " + section, JLabel.CENTER);
        sectionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        sectionLabel.setForeground(new Color(25, 25, 112)); // Midnight blue
        
        JLabel groupLabel = new JLabel("Group Name: " + groupName, JLabel.CENTER);
        groupLabel.setFont(new Font("Arial", Font.BOLD, 16));
        groupLabel.setForeground(new Color(25, 25, 112)); // Midnight blue
        
        infoPanel.add(sectionLabel);
        infoPanel.add(groupLabel);

        // Create table for member data with custom colors
        String[] columnNames = {"Roll No", "First Name", "Last Name", "ID Number"};
        Object[][] data = new Object[members.length][4];
        
        for (int i = 0; i < members.length; i++) {
            System.arraycopy(members[i], 0, data[i], 0, members[i].length);
        }

        JTable table = new JTable(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };

        // Custom table styling
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setShowGrid(true);
        table.setGridColor(new Color(200, 200, 200));
        
        // Header styling
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setBackground(new Color(70, 130, 180)); // Steel blue
        header.setForeground(Color.WHITE);
        
        // Cell renderer for alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, 
                        isSelected, hasFocus, row, column);
                
                if (row % 2 == 0) {
                    c.setBackground(new Color(240, 248, 255)); // Alice blue
                } else {
                    c.setBackground(new Color(224, 255, 255)); // Light cyan
                }
                
                c.setForeground(Color.BLACK);
                setHorizontalAlignment(JLabel.CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        // Create button panel with styled button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
        
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setPreferredSize(new Dimension(120, 35));
        closeButton.setBackground(new Color(70, 130, 180)); // Steel blue
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(47, 79, 79)), // Dark slate gray
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Button hover effects
        closeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                closeButton.setBackground(new Color(100, 149, 237)); // Cornflower blue
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                closeButton.setBackground(new Color(70, 130, 180)); // Steel blue
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        
        buttonPanel.add(closeButton);

        // Create a container panel for university info and header
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(universityPanel, BorderLayout.NORTH);
        topPanel.add(headerPanel, BorderLayout.CENTER);

        // Add components to frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(infoPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Center the frame on screen
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}