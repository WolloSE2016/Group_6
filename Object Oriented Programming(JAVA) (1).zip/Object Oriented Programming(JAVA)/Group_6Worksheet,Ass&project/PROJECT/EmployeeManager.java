package com.mycompany.employeemanager;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.spec.KeySpec;

public class EmployeeManager {
    private static final String FILE_PATH = "employee_records.dat";
    private static final String SALT = "aFixedSaltValue123"; // Should be configurable in production
    private static final int MAX_LOGIN_ATTEMPTS = 3;
    private static int loginAttempts = 0;
    private static List<Employee> employees = new ArrayList<>();

    private static class Employee implements Serializable {
        private static final long serialVersionUID = 1L;
        String name;
        String securityCode;

        Employee(String name, String securityCode) {
            this.name = name;
            this.securityCode = securityCode;
        }

        @Override
        public String toString() {
            return "Name: " + name + " | Security Code: " + securityCode;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowLogin());
    }

    private static void createAndShowLogin() {
        JFrame loginFrame = new JFrame("Employee System Login");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(400, 250);
        loginFrame.setLayout(new BorderLayout(10, 10));

        // Create a gradient panel for the background
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(173, 216, 230); // Light blue
                Color color2 = new Color(0, 191, 255);    // Deeper blue
                g2d.setPaint(new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2));
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        backgroundPanel.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setOpaque(false); // Make transparent to show background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Create styled title with bold "JAVA"
        JLabel titleLabel = new JLabel("<html><center>EMPLOYEE MANAGEMENT SYSTEM<br><b>JAVA</b> PROGRAM</center></html>", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);

        JLabel userLabel = new JLabel("Username:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(userLabel, gbc);

        JTextField userText = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 1;
        mainPanel.add(userText, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(passwordLabel, gbc);

        JPasswordField passwordText = new JPasswordField(15);
        gbc.gridx = 1;
        gbc.gridy = 2;
        mainPanel.add(passwordText, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setOpaque(false);
        JButton loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(100, 30));
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setPreferredSize(new Dimension(100, 30));

        loginButton.addActionListener(e -> {
            String username = userText.getText();
            char[] password = passwordText.getPassword();

            if (authenticate(username, password)) {
                loginFrame.dispose();
                loadRecords();
                createAndShowMainUI();
            } else {
                loginAttempts++;
                if (loginAttempts >= MAX_LOGIN_ATTEMPTS) {
                    JOptionPane.showMessageDialog(loginFrame, 
                        "Maximum login attempts reached. System will exit.", 
                        "Security Alert", JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                } else {
                    JOptionPane.showMessageDialog(loginFrame, 
                        "Invalid attempts to login. Attempts remaining: " + (MAX_LOGIN_ATTEMPTS - loginAttempts), 
                        "Login Failed", JOptionPane.WARNING_MESSAGE);
                    passwordText.setText("");
                }
            }
        });

        cancelButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        mainPanel.add(buttonPanel, gbc);

        backgroundPanel.add(mainPanel, BorderLayout.CENTER);
        loginFrame.add(backgroundPanel, BorderLayout.CENTER);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setVisible(true);
    }

    private static boolean authenticate(String username, char[] password) {
        // In production, use proper password hashing and database storage
        String storedUsername = "java";
        String storedPasswordHash = hashPassword("java1234".toCharArray());
        
        return storedUsername.equals(username) && 
               storedPasswordHash.equals(hashPassword(password));
    }

    private static String hashPassword(char[] password) {
        try {
            KeySpec spec = new PBEKeySpec(password, SALT.getBytes(), 65536, 256);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private static void createAndShowMainUI() {
        JFrame mainFrame = new JFrame("Employee Manager");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(700, 500);

        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.add(new JLabel("Employee Security Code Management System", SwingConstants.CENTER));
        
        // Output area
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton addButton = new JButton("Add Employee");
        JButton viewButton = new JButton("View Employees");
        JButton exitButton = new JButton("Save and Exit");

        addButton.addActionListener(e -> showAddEmployeeDialog(outputArea));
        viewButton.addActionListener(e -> displayEmployees(outputArea));
        exitButton.addActionListener(e -> {
            saveRecords();
            mainFrame.dispose();
            System.exit(0);
        });

        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(exitButton);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        mainFrame.add(mainPanel);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    private static void showAddEmployeeDialog(JTextArea outputArea) {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        JTextField nameField = new JTextField();
        JPasswordField codeField = new JPasswordField();
        
        // Add document filters for validation
        ((AbstractDocument) nameField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) 
                throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.matches("[a-zA-Z ]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        ((AbstractDocument) codeField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) 
                throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.matches("[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        panel.add(new JLabel("Name :"));
        panel.add(nameField);
        panel.add(new JLabel("Security Code :"));
        panel.add(codeField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Add New Employee", 
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String code = new String(codeField.getPassword());
            
            if (!name.isEmpty() && !code.isEmpty()) {
                if (!name.matches("[a-zA-Z ]+")) {
                    JOptionPane.showMessageDialog(null, "Name can only contain letters", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (!code.matches("[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]+")) {
                    JOptionPane.showMessageDialog(null, 
                        "Security code can only contain letters and special characters", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                employees.add(new Employee(name, code));
                saveRecords();
                outputArea.append("Employee added: " + name + "\n");
            } else {
                JOptionPane.showMessageDialog(null, "Name and Security Code cannot be empty", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void displayEmployees(JTextArea outputArea) {
        outputArea.setText("");
        if (employees.isEmpty()) {
            outputArea.append("No employees in the system.\n");
        } else {
            outputArea.append(String.format("%-20s %-20s\n", "Name", "Security Code"));
            outputArea.append("----------------------------------------\n");
            employees.forEach(emp -> 
                outputArea.append(String.format("%-20s %-20s\n", emp.name, emp.securityCode)));
        }
    }

    private static void saveRecords() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            List<Employee> encryptedEmployees = new ArrayList<>();
            for (Employee emp : employees) {
                String encryptedCode = encrypt(emp.securityCode);
                if (encryptedCode == null) {
                    throw new Exception("Encryption failed for employee: " + emp.name);
                }
                encryptedEmployees.add(new Employee(emp.name, encryptedCode));
            }
            oos.writeObject(encryptedEmployees);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving records: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void loadRecords() {
        File file = new File(FILE_PATH);
        if (!file.exists()) return;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            @SuppressWarnings("unchecked")
            List<Employee> encryptedEmployees = (List<Employee>) ois.readObject();
            employees.clear();
            for (Employee emp : encryptedEmployees) {
                String decryptedCode = decrypt(emp.securityCode);
                if (decryptedCode == null) {
                    throw new Exception("Decryption failed for employee: " + emp.name);
                }
                employees.add(new Employee(emp.name, decryptedCode));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading records: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static String encrypt(String input) {
        try {
            IvParameterSpec iv = generateIv();
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, getKeyFromPassword(), iv);
            byte[] cipherText = cipher.doFinal(input.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(iv.getIV()) + 
                   "|" + Base64.getEncoder().encodeToString(cipherText);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Encryption failed: " + e.getMessage(),
                "Encryption Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private static String decrypt(String input) {
        if (input == null || !input.contains("|")) {
            return null;
        }
        try {
            String[] parts = input.split("\\|");
            IvParameterSpec iv = new IvParameterSpec(Base64.getDecoder().decode(parts[0]));
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, getKeyFromPassword(), iv);
            byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(parts[1]));
            return new String(plainText, StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Decryption failed: " + e.getMessage(),
                "Decryption Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private static SecretKey getKeyFromPassword() throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec("securePass".toCharArray(), SALT.getBytes(), 65536, 256);
        return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
    }

    private static IvParameterSpec generateIv() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }
}