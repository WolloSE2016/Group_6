/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignmentprograms;
import java.util.Scanner;
public class AssignmentPrograms {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        do {
            System.out.println("\n===== ASSIGNMENT PROGRAMS MENU =====");
            System.out.println("1. Question 1 - Statistics Calculator");
            System.out.println("2. Question 2 - Second Largest Number");
            System.out.println("3. Question 3 - Same Number of Factors");
            System.out.println("4. Question 4 - Paired N Check");
            System.out.println("0. Exit");
            System.out.print("\nEnter your choice (1-4 or 0 to exit): ");
            
            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch(choice) {
                    case 1: 
                        // Question 1: Statistics Calculator
                        runStatCalc(scanner);
                        break;
                    case 2: 
                        // Question 2: Second Largest Number
                        runSecondLargest(scanner);
                        break;
                    case 3: 
                        // Question 3: Same Number of Factors
                        runSameNumberOfFactors(scanner);
                        break;
                    case 4: 
                        // Question 4: Paired N Check
                        runPairedN(scanner);
                        break;
                    case 0: 
                        System.out.println("\nExiting program...");
                        break;
                    default: 
                        System.out.println("\nInvalid choice! Please enter a number between 0-4.");
                }
                
                if(choice != 0) {
                    System.out.print("\nPress Enter to return to menu...");
                    scanner.nextLine();
                }
            } catch(Exception e) {
                System.out.println("\nInvalid input! Please enter a number.");
                scanner.nextLine();
                choice = -1;
            }
        } while(choice != 0);
        
        scanner.close();
    }
    
    // Question 1: Statistics Calculator
    private static void runStatCalc(Scanner scanner) {
        System.out.println("\nQUESTION 1: STATISTICS CALCULATOR");
        StatCalc calc = new StatCalc();
        System.out.println("Enter numbers (enter 0 to stop):");
        
        while(true) {
            double item = scanner.nextDouble();
            if(item == 0) break;
            calc.enter(item);
        }
        
        if(calc.getCount() == 0) {
            System.out.println("No elements in the dataset");
        } else {
            System.out.println("Number of items: " + calc.getCount());
            calc.getSum();
            System.out.println("Mean: " + calc.getMean());
            calc.getMax();
            calc.getMin();
            calc.getStandarddeviation();
        }
    }
    
    // Question 2: Second Largest Number
    private static void runSecondLargest(Scanner scanner) {
        System.out.println("\nQUESTION 2: SECOND LARGEST NUMBER");
        System.out.print("How many integers? ");
        int size = scanner.nextInt();
        int[] a = new int[size];
        
        System.out.println("Enter your integers:");
        for(int i = 0; i < size; i++) {
            a[i] = scanner.nextInt();
        }
        
        Function fun = new Function();
        int result = fun.f(a);
        System.out.println("Second largest number: " + result);
    }
    
    // Question 3: Same Number of Factors
    private static void runSameNumberOfFactors(Scanner scanner) {
        System.out.println("\nQUESTION 3: SAME NUMBER OF FACTORS");
        System.out.print("Enter two integers: ");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();
        
        SameNumberOfFactors fact = new SameNumberOfFactors();
        int result = fact.sameNumberOfFactors(num1, num2);
        System.out.println("Result: " + result);
    }
    
    // Question 4: Paired N Check
    private static void runPairedN(Scanner scanner) {
        System.out.println("\nQUESTION 4: PAIRED N CHECK");
        System.out.print("Enter array size: ");
        int size = scanner.nextInt();
        System.out.print("Enter N value: ");
        int n = scanner.nextInt();
        
        int[] a = new int[size];
        System.out.println("Enter array elements:");
        for(int i = 0; i < size; i++) {
            a[i] = scanner.nextInt();
        }
        
        PairedN pair = new PairedN();
        int result = pair.isPairedN(a, n);
        System.out.println("Output: " + result);
    }
    
    // ========== CLASS DEFINITIONS ==========
    
    // Question 1 implementation
    static class StatCalc {
        private int count;
        private double sum;
        private double max = Double.MIN_VALUE;
        private double min = Double.MAX_VALUE;
        private double sqrSum;
        
        public void enter(double item) {
            count++;
            sum += item;
            if(item > max) max = item;
            if(item < min) min = item;
            sqrSum += item * item;
        }
        
        public int getCount() { return count; }
        
        public void getSum() {
            System.out.println("Sum: " + sum);
        }
        
        public double getMean() {
            return sum / count;
        }
        
        public void getMax() {
            System.out.println("Max: " + max);
        }
        
        public void getMin() {
            System.out.println("Min: " + min);
        }
        
        public void getStandarddeviation() {
            double mean = getMean();
            double standDev = Math.sqrt((sqrSum / count) - (mean * mean));
            System.out.println("Standard deviation: " + standDev);
        }
    }
    
    // Question 2 implementation
    static class Function {
        public int f(int[] a) {
            if(a.length < 2) return -1;
            
            int first = Integer.MIN_VALUE;
            int second = Integer.MIN_VALUE;
            
            for(int num : a) {
                if(num > first) {
                    second = first;
                    first = num;
                } else if(num > second && num < first) {
                    second = num;
                }
            }
            return second;
        }
    }
    
    // Question 3 implementation
    static class SameNumberOfFactors {
        int sameNumberOfFactors(int n1, int n2) {
            if(n1 < 0 || n2 < 0) return -1;
            
            int count1 = countFactors(n1);
            int count2 = countFactors(n2);
            
            System.out.println("Factors of n1: " + count1);
            System.out.println("Factors of n2: " + count2);
            
            return (count1 == count2) ? 1 : 0;
        }
        
        private int countFactors(int n) {
            if(n == 0) return 0;
            int count = 0;
            for(int i = 1; i <= n; i++) {
                if(n % i == 0) count++;
            }
            return count;
        }
    }
    
    // Question 4 implementation
    static class PairedN {
        int isPairedN(int[] a, int n) {
            if(a.length < 2) return 0;
            
            for(int i = 0; i < a.length; i++) {
                for(int j = i + 1; j < a.length; j++) {
                    if(a[i] + a[j] == n && i + j == n) {
                        return 1;
                    }
                }
            }
            return 0;
        }
    }
}