/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.statcalc;
import java.util.Scanner;
public class StatCalc {
    private static int count;
    private static double sum;
    private static double mean;
    private static double max;
    private static double min;
    private static double sqrSum;
    public StatCalc( ){
        int count = 0;
        double sum = 0; 
        double mean = 0;
        double max = 0;
        double min = 0;
        double sqrSum = 0;
    }
    public static void enter(double item){
        count++;
        sum+=item;
       mean = sum/count;
       if(max < item)
           max = item;
        if(item < min)
            min = item;
        sqrSum+= item * item;
    }
    public int getCount(){
        return count;
    }
public void getSum(){
System.out.println("Sum of items in the dataset  "+ sum);
} 
public double getMean(){
    if(count == 0)
        return Double.NaN;
        return mean;
}
public void getMax(){
    if(count == 0)
        System.out.println(Double.NaN);
    System.out.println("The largest item in the dataset  "+max);
}
public void getMin(){
    if(count == 0)
        System.out.println(Double.NaN);
    System.out.println("The smallest item in the dataset   "+min);
}
public void getStandarddeviation(){
    if (count == 0)
    System.out.println(Double.NaN);
    double mean = getMean();
         double standDev = Math.sqrt((sqrSum / count) - (mean * mean));
    System.out.println("The standard deviation of the dataset  "+standDev);
}
    public static void main(String[] args) {
                        System.out.println("QUESTION NUMBER 1 FROM ASSIGNMENT!");
        System.out.println("A JAVA PROGRAM FOR STATISTICS!");
          Scanner scanner = new Scanner(System.in); 
          StatCalc calc = new StatCalc();
          System.out .println("Enter a number you want to add");
          //
          while(true){
          double item = scanner.nextDouble();
          if(item == 0)
              break;
          calc.enter(item);
          }
          if(calc.getCount()== 0){
              System.out.println("No elements in the dataset");
          }else{
              calc.getCount();
              System.out.println("Number of items in the dataset   "+ count);
              calc.getSum( );
              calc.getMean();
              System.out.println("Mean of the dataset  "+ mean);
              calc.getMax();
              calc.getMin();
              calc.getStandarddeviation();

          }
    }
}
