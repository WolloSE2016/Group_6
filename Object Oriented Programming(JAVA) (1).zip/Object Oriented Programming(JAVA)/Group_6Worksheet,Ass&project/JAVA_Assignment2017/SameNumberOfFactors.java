/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.samenumberoffactors;
import java.util.Scanner;
public class SameNumberOfFactors {
   public SameNumberOfFactors(){
             
   }
    int sameNumberOfFactors(int n1, int n2){
             int count1 = 0;
              int count2 = 0;
        if(n1 < 0 || n2 < 0){
            return -1; 
        }else  {
            for(int i = 1; i <= n1; i++){
                if(n1%i == 0)
                    count1++;
            }
                System.out.println("number of factors of n1 "+count1);
            for(int j = 1; j <= n2; j++){
                if(n2%j == 0)
                    count2++;
            }
               System.out.println("number of factors of n2 "+count2);
            
              }
            if(count1 == count2 || (n1 == 0 && n2 == 0)){
                return 1;
            }else if(count1 != count2 || (n1 == 0 || n2 == 1) || (n1 == 1 || n2 == 0)){
                return 0;
            }
            return 0;
        }


    public static void main(String[] args) {
        System.out.println("QUESTION NUMBER 3 FROM Assignment!");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Pls enter two integers");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();
        SameNumberOfFactors fact = new SameNumberOfFactors();
        int result = fact.sameNumberOfFactors(num1,num2);
        System.out.print("returning a value of factor between 2 numbers "+result);
    }
}
