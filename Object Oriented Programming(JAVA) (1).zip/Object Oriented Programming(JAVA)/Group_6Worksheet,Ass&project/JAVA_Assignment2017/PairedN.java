/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pairedn;
import java.util.Scanner;
public class PairedN {
    public PairedN(){
        
    }
int isPairedN(int[] a, int n){
    if(a.length < 2){
        return 0;
    }
    for(int i = 0; i < a.length; i++){
        for(int j = i + 1; j < a.length; j++){
        if(a[i] + a[i+1] == n && i + (i+1) == n)
            return 1;
        }
        }
    return 0;   
}
    public static void main(String[] args) {
        System.out.println("QUESTION NUMBER 4 FROM Assignment!");
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter your size of array!");
                int size = scanner.nextInt();
                System.out.println("enter N to check paired array ! ");
                int n = scanner.nextInt();
                int[] a =new int[size];
                     System.out.println("enter each elements of the  array ! ");
              for(int i = 0; i < size; i++){
                  a[i] = scanner.nextInt();
              }
                  PairedN pair = new PairedN();
                  int result = pair.isPairedN( a, n);
                   System.out.println("output "+ result);
              }
              }
    

