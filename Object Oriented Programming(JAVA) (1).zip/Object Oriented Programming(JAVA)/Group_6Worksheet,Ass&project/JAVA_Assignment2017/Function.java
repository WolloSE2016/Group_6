/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.function;
import java.util.Scanner;
public class Function {

     public Function() {
        // Constructor remains empty
    }

    public int f(int[] a) {
        if (a.length < 2) {
            return -1;
        }
        
        int firstLarge = Integer.MIN_VALUE;
        int secondLarge = Integer.MIN_VALUE;

        for (int num : a) {
            if (num > firstLarge) {
                secondLarge = firstLarge;
                firstLarge = num;
            } else if (num > secondLarge && num < firstLarge) {
                secondLarge = num;
            }
        }
        
        return secondLarge ;
    }

    public static void main(String[] args) {
        System.out.println("QUESTION NUMBER 2 FROM Assignment!");

        System.out.println("Displaying the second largest integer from given array!");
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("How many integers do you want to enter?");
        int size = scanner.nextInt();
        int[] a = new int[size];
        
        Function fun = new Function();
        
        System.out.println("Enter your integers:");
        for (int i = 0; i < a.length; i++) {
            a[i] = scanner.nextInt();
        }
        
        int result = fun.f(a);
        
            System.out.println("Second largest number: " + result);
        
        
        scanner.close();
    }
}

