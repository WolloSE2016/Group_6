/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employeereport;
import java.util.Scanner;

public class EmployeeReport {
    static class Employee {
        String lastName;
        String firstName;
        double hourlyWage;
        int yearsWithCompany;
        
        // Constructor
        public Employee(String lastName, String firstName, double hourlyWage, int yearsWithCompany) {
            this.lastName = lastName;
            this.firstName = firstName;
            this.hourlyWage = hourlyWage;
            this.yearsWithCompany = yearsWithCompany;
        }
    }

    public static void main(String[] args) {
                        System.out.println("QUESTION NUMBER 11 FROM WORKSHEET!");
        Scanner scanner = new Scanner(System.in);
        Employee[] employeeData = new Employee[100];
        
        System.out.println("Enter employee information (up to 100 employees)");
        int count = 0;
        while (count < 2) {
            System.out.println("\nEmployee #" + (count + 1));
            
            System.out.print("First Name: ");
            String firstName = scanner.nextLine();                     
            System.out.print("Last Name: ");
            String lastName = scanner.nextLine();
            
            System.out.print("Hourly Wage: ");
            double hourlyWage = scanner.nextDouble();
            
            System.out.print("Years with Company: ");
            int yearsWithCompany = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            employeeData[count] = new Employee(lastName, firstName, hourlyWage, yearsWithCompany);
            count++;
        }

        // Display employees with 20+ years
        System.out.println("\nEmployees with 20+ years of service:");
        System.out.println("-----------------------------------");
        
        boolean found = false;
                        System.out.println("First Name      Last Name       Hourly Wage");
        for (int i = 0; i < count; i++) {
            Employee emp = employeeData[i];
            if (emp.yearsWithCompany >= 20) {
                                System.out.println(emp.firstName +"              "+emp.lastName +"            "+emp.hourlyWage);
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No employees found with 20+ years of service.");
        }
        
        scanner.close();
    }
}
