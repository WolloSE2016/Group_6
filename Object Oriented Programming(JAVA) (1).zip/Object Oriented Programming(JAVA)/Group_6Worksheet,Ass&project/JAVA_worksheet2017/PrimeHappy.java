/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primehappy;

import java.util.Scanner;
public class PrimeHappy {
    public PrimeHappy(){
        
    }
    public static boolean isPrime(int num){
        if(num <=1){
            return false;
        }    
        if(num <=2){
            return true;
        } 
        if(num % 2 ==0){
            return false;
        }  
        for(int i = 3; i*i <= num; i+=2){
           if(num % i == 0){
            return false;
        }  
        }  
        return true;
        }
    
     public static int isPrimeHappy (int n){
        if(n <= 2)
           return 0;
          int sum = 0;
      boolean hasPrime = false;
        for(int i = 2; i < n; i++){         
                if(isPrime(i)){
                hasPrime = true;
                sum+=i;
                }
            }
        
              if(!hasPrime){
                return 0;
        }
if(sum%n == 0){
return 1;
}else{
        return 0;
    }
}

    public static void main(String[] args) {
        System.out.println("QUESTION NUMBER 14 FROM WORKSHEET! " );
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter an integer");
        int n = scanner.nextInt();
        PrimeHappy happy = new PrimeHappy();
        System.out.println(isPrimeHappy(n));

        scanner.close();
    }
}
