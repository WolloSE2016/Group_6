/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stepped;
import java.util.Scanner;
public class Stepped {
    public Stepped(){
        
    }
   int isStepped(int[] a){
       if( a.length == 0){
           return 0;
       }
     
         for(int i = 0; i < a.length - 1; i++){
             if(a[i] > a[i+1] ){
                 return 0;
             }
         }
         //cheking occurrence of each distinct value
         int actual = a[0];
         int count = 1;
         for(int j = 1; j < a.length; j++){
             if(a[j] == actual){
                 count++;
             }else{
                 // checking if the previous value has at least 3 occurance
                 if(count < 3){
                     return 0;
                 }
                 actual = a[j];
                 count = 1;
             }
         }
         if(count < 3){
             return 0;
         }
       return 1;
   }

    public static void main(String[] args) {
                System.out.println("QUESTION NUMBER 16 FROM WORKSHEET!");
        Scanner scanner = new Scanner(System.in);
        Stepped stepped = new Stepped();
        System.out.println("how much is array size must be?");
        int size ;
        size =scanner.nextInt();
        int[] arr = new int[size];
                System.out.println("pls enter array elements!");
        for(int k = 0; k < size; k++){
            arr[k] = scanner.nextInt();
        }
        int value = stepped.isStepped(arr);
        
        System.out.println("the result of checking the given array is stepped: "+value);
        
    }
}
