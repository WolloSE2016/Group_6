/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.playepro;
public class Playepro {
    private String name;
    private int price;

    // Constructor
    public  Playepro(String name, int price) {
        this.name = name;
        this.price = price;
    }

    // Getter for name
    public String getName() {
        return this.name;
    }

    // Getter for price
    public int getPrice() {
        return this.price;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Setter for price
    public void setPrice(int price) {
        this.price = price;
    }

    public static void main(String[] args) {
                                System.out.println("QUESTION NUMBER 8 FROM WORKSHEET!");
        // Create a Player object
        Playepro footB = new Playepro("Ronaldo", 400000);       
        // Demonstrate setters (though we already set values in constructor)
        footB.setName("Ronaldo");
        footB.setPrice(400000);
        
        // Print player information
        System.out.println("Player: " +footB.getName() + ", Price: " + footB.getPrice());
    }
}