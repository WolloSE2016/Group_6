/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.paritysum;
import java.util.Scanner;
public class ParitySum {
    int evenSum;
    int oddSum;
    public ParitySum(){
         this.evenSum = 0;
         this.oddSum = 0;
    }
    public int f(int[] a){
        for(int i = 0; i < a.length; i++){
            if(a[i]%2 == 0){
                evenSum+= a[i];
            }else
                oddSum+= a[i];
        }
            
        
        System.out.println("total sum of even elements:  " + evenSum);
                System.out.println("total sum of odd elements:  " + oddSum);

        return oddSum -evenSum ;
    }

    public static void main(String[] args) {
                System.out.println("QUESTION NUMBER 15 FROM WORKSHEET !");
        Scanner scanner = new Scanner(System.in);
        ParitySum parity = new ParitySum();
        System.out.println("how much must be the size of your array?");
        int size = scanner.nextInt();
        int[] a = new int[size];
        System.out.println("Enter elements of the array !");
        for(int t = 0; t < a.length; t++){
        a[t] = scanner.nextInt();
        }
        int difference = parity.f(a);
        System.out.println("the difference of even elements from odds in the given array: "+difference);
        scanner.close();
    }
}
