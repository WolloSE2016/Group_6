/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.counter;
import java.util.Scanner;
public class Counter {
    private int count;
    public Counter(){
        this.count = 0;
    }
    void increment(){
        
            count++;
        }
    
    public int getValue(){
        
        return this.count;
    }

    public static void main(String[] args) {
                                System.out.println("QUESTION NUMBER 9 FROM WORKSHEET!");
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the number to check the program ! ");
        int n = scanner.nextInt();
                Counter counter = new Counter();    
                        System.out.print( "counter  :  ");
        while(true){          
        int countee = counter.getValue();
        System.out.print( countee +",");
                counter.increment();
                if(countee == n)
                break;
        }
    }
}
