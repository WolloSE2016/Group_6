/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sample_output;
public class Sample_output {
    Sample_output(){
        int N;
        N=1;
        while(N<=32){
          N =N*2;
       System.out.println(N);
        
        }
        }
    //int Biproduct(){
   
       // return 0;
    //}
    
    public static void main(String[] args) {
                                System.out.println("QUESTION NUMBER 3 FROM WORKSHEET!");
        System.out.println("Sample out of numbers less than 32 by double it");
        Sample_output Double= new Sample_output();
        //Double.Biproduct();
    }
}
