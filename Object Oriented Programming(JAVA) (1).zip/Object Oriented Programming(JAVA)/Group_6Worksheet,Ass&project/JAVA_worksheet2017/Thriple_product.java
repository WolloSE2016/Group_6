
package com.mycompany.thriple_product;
public class Thriple_product {

    public static void main(String[] args) {
                                System.out.println("QUESTION NUMBER 2 FROM WORKSHEET!");
        System.out.println("this is multiple of three less than 36");
        int n=12,i=1;
         System.out.print("products of three <36 are:");
        while(i<=n){
            System.out.print(i*3+" ");
            i++;
        }
    }
}
