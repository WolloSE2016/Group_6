/*
THE CODE FOR ALL QUESTIONS IN A ONE PACKAGE */

package com.mycompany.worksheetprograms;
import java.util.Scanner;
import java.util.Random;

public class WorksheetPrograms {
    
    // Question 2: Triple Product
    static class TripleProduct {
        public static void run() {
            System.out.println("\nQUESTION NUMBER 2 FROM WORKSHEET - TRIPLE PRODUCT");
            System.out.println("Multiples of three less than 36:");
            int n = 12, i = 1;
            System.out.print("Products of three <36 are: ");
            while(i <= n) {
                System.out.print(i * 3 + " ");
                i++;
            }
            System.out.println();
        }
    }
    
    // Question 3: Sample Output
    static class SampleOutput {
        public static void run() {
            System.out.println("\nQUESTION NUMBER 3 FROM WORKSHEET - SAMPLE OUTPUT");
            System.out.println("Numbers less than 32 by doubling:");
            int N = 1;
            while(N <= 32) {
                N = N * 2;
                System.out.println(N);
            }
        }
    }
    
    // Question 4: Array Operations (using Largest.java implementation)
    static class ArrayOperations {
        public static void run() {
            System.out.println("\nQUESTION NUMBER 4 FROM WORKSHEET - ARRAY OPERATIONS");
            Scanner scanner = new Scanner(System.in);
            
            System.out.print("Size of 1D array: ");
            int size = scanner.nextInt();
            System.out.println("Please enter 1D array elements:");
            int[] sampleArray = new int[size];
            for(int k = 0; k < size; k++) {
                sampleArray[k] = scanner.nextInt();
            }
            
            System.out.print("Row size of 2D array: ");
            int row = scanner.nextInt();
            System.out.print("Column size of 2D array: ");
            int column = scanner.nextInt();
            int[][] twoD = new int[row][column];
            System.out.println("Please enter 2D array elements:");
            for(int i = 0; i < row; i++) {
                for(int j = 0; j < column; j++) {
                    twoD[i][j] = scanner.nextInt();
                }
            }
            
            System.out.println("The largest value in 1D array: " + findMax(sampleArray));
            System.out.println("The largest value in 2D array: " + findMax(twoD));
        }
        
        private static int findMax(int[] arr) {
            int large = arr[0];
            for(int t = 1; t <= arr.length - 1; t++) {
                if(arr[t] > large) large = arr[t];
            }
            return large;
        }
        
        private static int findMax(int[][] twoDarr) {
            int largest = twoDarr[0][0];
            for(int i = 0; i < twoDarr.length; i++) {
                for(int j = 0; j < twoDarr[i].length; j++) {
                    if(twoDarr[i][j] > largest) largest = twoDarr[i][j];
                }
            }
            return largest;
        }
    }
    
    // Question 5: Double Array Operations
    static class DoubleArrayOperations {
        public static void run() {
            System.out.println("\nQUESTION NUMBER 5 FROM WORKSHEET - DOUBLE ARRAY OPERATIONS");
            double[] A = new double[20];
            Scanner scanner = new Scanner(System.in);
            
            System.out.println("Please enter 20 float numbers:");
            for(int i = 0; i < 20; i++) {
                A[i] = scanner.nextDouble();
            }
            
            System.out.println("\nInitial array values:");
            displayArray(A);
            
            double average = calculateAverage(A);
            System.out.println("Average of values in the array: " + average);
            
            int count = countNonZero(A);
            System.out.println("Total numbers of non-zero values: " + count);
        }
        
        public static void displayArray(double[] A) {
            System.out.println("Elements  Values");
            for(int i = 0; i < A.length; i++) {
                System.out.printf("%-8d:  %.2f\n", (i+1), A[i]);
            }
        }
        
        public static double calculateAverage(double[] A) {
            double sum = 0.0;
            for(int i = 0; i < A.length; i++) {
                if(A[i] != 0) {
                    sum += A[i];
                }
            }
            return sum / A.length;
        }
        
        public static int countNonZero(double[] A) {
            int count = 0;
            for(int i = 0; i < A.length; i++) {
                if(A[i] != 0) {
                    count++;
                }
            }
            return count;
        }
    }
    
    // Question 8: Player Program
    static class PlayerProgram {
        private String name;
        private int price;
        
        public PlayerProgram(String name, int price) {
            this.name = name;
            this.price = price;
        }
        
        public String getName() { return this.name; }
        public int getPrice() { return this.price; }
        public void setName(String name) { this.name = name; }
        public void setPrice(int price) { this.price = price; }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 8 FROM WORKSHEET - PLAYER PROGRAM");
            PlayerProgram footB = new PlayerProgram("Ronaldo", 400000);
            footB.setName("Ronaldo");
            footB.setPrice(400000);
            System.out.println("Player: " + footB.getName() + ", Price: " + footB.getPrice());
        }
    }
    
    // Question 9: Counter
    static class CounterProgram {
        private int count;
        
        public CounterProgram() { this.count = 0; }
        void increment() { count++; }
        public int getValue() { return this.count; }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 9 FROM WORKSHEET - COUNTER");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the number to check the program: ");
            int n = scanner.nextInt();
            CounterProgram counter = new CounterProgram();
            System.out.print("Counter: ");
            
            while(true) {
                int countee = counter.getValue();
                System.out.print(countee + ",");
                counter.increment();
                if(countee == n) break;
            }
            System.out.println();
        }
    }
    
    // Question 10: Coin Tossing
    static class CoinTossing {
        int headCount;
        int tailCount;
        
        public CoinTossing() {
            this.headCount = 0;
            this.tailCount = 0;
        }
        
        public void getHeadCount() { headCount++; }
        public void getTailCount() { tailCount++; }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 10 FROM WORKSHEET - COIN TOSSING");
            CoinTossing coin = new CoinTossing();
            Random random = new Random();
            
            for(int i = 1; i <= 100; i++) {
                boolean isHead = random.nextBoolean();
                if(isHead) {
                    coin.getHeadCount();
                } else {
                    coin.getTailCount();
                }
            }
            
            System.out.println("Total number of outcomes as head: " + coin.headCount);
            System.out.println("Total number of outcomes as tail: " + coin.tailCount);
        }
    }
    
    // Question 11: Employee Report
    static class EmployeeReport {
        static class Employee {
            String lastName;
            String firstName;
            double hourlyWage;
            int yearsWithCompany;
            
            public Employee(String lastName, String firstName, double hourlyWage, int yearsWithCompany) {
                this.lastName = lastName;
                this.firstName = firstName;
                this.hourlyWage = hourlyWage;
                this.yearsWithCompany = yearsWithCompany;
            }
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 11 FROM WORKSHEET - EMPLOYEE REPORT");
            Scanner scanner = new Scanner(System.in);
            Employee[] employeeData = new Employee[100];
            
            System.out.println("Enter employee information (up to 100 employees)");
            int count = 0;
            while(count < 2) { // For demo purposes, limited to 2 employees
                System.out.println("\nEmployee #" + (count + 1));
                System.out.print("First Name: ");
                String firstName = scanner.nextLine();
                System.out.print("Last Name: ");
                String lastName = scanner.nextLine();
                System.out.print("Hourly Wage: ");
                double hourlyWage = scanner.nextDouble();
                System.out.print("Years with Company: ");
                int yearsWithCompany = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                employeeData[count] = new Employee(lastName, firstName, hourlyWage, yearsWithCompany);
                count++;
            }
            
            System.out.println("\nEmployees with 20+ years of service:");
            System.out.println("-----------------------------------");
            System.out.println("First Name      Last Name       Hourly Wage");
            
            boolean found = false;
            for(int i = 0; i < count; i++) {
                Employee emp = employeeData[i];
                if(emp.yearsWithCompany >= 20) {
                    System.out.printf("%-15s %-15s %.2f\n", emp.firstName, emp.lastName, emp.hourlyWage);
                    found = true;
                }
            }
            
            if(!found) {
                System.out.println("No employees found with 20+ years of service.");
            }
        }
    }
    
    // Question 12: Dice Game
    static class DiceGame {
        public static class PairOfDice {
            private int die1;
            private int die2;
            private int rollCount;
            
            public PairOfDice() { roll(); }
            
            public void roll() {
                die1 = (int)(Math.random() * 6) + 1;
                die2 = (int)(Math.random() * 6) + 1;
                rollCount++;
            }
            
            public int getDie1() { return die1; }
            public int getDie2() { return die2; }
            public int getTotal() { return die1 + die2; }
            public int getRollCount() { return rollCount; }
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 12 FROM WORKSHEET - DICE GAME");
            PairOfDice dice = new PairOfDice();
            
            while(dice.getTotal() != 2) {
                dice.roll();
                System.out.printf("Roll %d: %d + %d = %d%n",
                               dice.getRollCount(),
                               dice.getDie1(),
                               dice.getDie2(),
                               dice.getTotal());
            }
            System.out.println("Got snake eyes after " + dice.getRollCount() + " rolls!");
        }
    }
    
    // Question 13: Fibonacci
    static class FibonacciProgram {
        int[] arr;
        
        public FibonacciProgram() {}
        
        int closestFibonacci(int n) {
            if(n < 1) return 0;
            else if(n <= 2) return 1;
            
            arr = new int[n + 2];
            int max = 0;
            System.out.print("Fibonacci numbers under given number: ");
            
            for(int i = 1; i <= n; i++) {
                if(i == 1 || i == 2) {
                    arr[i] = 1;
                } else {
                    arr[i] = arr[i - 1] + arr[i - 2];
                }
                
                if(arr[i] > n) break;
                max = arr[i];
                System.out.print(arr[i] + ", ");
            }
            System.out.println();
            return max;
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 13 FROM WORKSHEET - FIBONACCI");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the checking number:");
            int number = scanner.nextInt();
            FibonacciProgram fibonacci = new FibonacciProgram();
            int result = fibonacci.closestFibonacci(number);
            
            if(number > 2) {
                System.out.println("Largest Fibonacci number ≤ " + number + ": " + result);
            } else {
                System.out.println("Result: " + result);
            }
        }
    }
    
    // Question 14: Prime Happy
    static class PrimeHappyProgram {
        public static boolean isPrime(int num) {
            if(num <= 1) return false;
            if(num <= 2) return true;
            if(num % 2 == 0) return false;
            for(int i = 3; i * i <= num; i += 2) {
                if(num % i == 0) return false;
            }
            return true;
        }
        
        public static int isPrimeHappy(int n) {
            if(n <= 2) return 0;
            int sum = 0;
            boolean hasPrime = false;
            
            for(int i = 2; i < n; i++) {
                if(isPrime(i)) {
                    hasPrime = true;
                    sum += i;
                }
            }
            
            if(!hasPrime) return 0;
            return (sum % n == 0) ? 1 : 0;
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 14 FROM WORKSHEET - PRIME HAPPY");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter an integer:");
            int n = scanner.nextInt();
            System.out.println("Result: " + isPrimeHappy(n));
        }
    }
    
    // Question 15: Parity Sum
    static class ParitySumProgram {
        int evenSum;
        int oddSum;
        
        public ParitySumProgram() {
            this.evenSum = 0;
            this.oddSum = 0;
        }
        
        public int calculate(int[] a) {
            for(int i = 0; i < a.length; i++) {
                if(a[i] % 2 == 0) {
                    evenSum += a[i];
                } else {
                    oddSum += a[i];
                }
            }
            
            System.out.println("Total sum of even elements: " + evenSum);
            System.out.println("Total sum of odd elements: " + oddSum);
            return oddSum - evenSum;
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 15 FROM WORKSHEET - PARITY SUM");
            Scanner scanner = new Scanner(System.in);
            ParitySumProgram parity = new ParitySumProgram();
            
            System.out.println("Enter size of your array:");
            int size = scanner.nextInt();
            int[] a = new int[size];
            System.out.println("Enter elements of the array:");
            
            for(int t = 0; t < size; t++) {
                a[t] = scanner.nextInt();
            }
            
            int difference = parity.calculate(a);
            System.out.println("Difference (odd - even): " + difference);
        }
    }
    
    // Question 16: Stepped Array
    static class SteppedArray {
        public int isStepped(int[] a) {
            if(a.length == 0) return 0;
            
            // Check if array is non-decreasing
            for(int i = 0; i < a.length - 1; i++) {
                if(a[i] > a[i + 1]) return 0;
            }
            
            // Check occurrence of each distinct value
            int actual = a[0];
            int count = 1;
            
            for(int j = 1; j < a.length; j++) {
                if(a[j] == actual) {
                    count++;
                } else {
                    if(count < 3) return 0;
                    actual = a[j];
                    count = 1;
                }
            }
            
            if(count < 3) return 0;
            return 1;
        }
        
        public static void run() {
            System.out.println("\nQUESTION NUMBER 16 FROM WORKSHEET - STEPPED ARRAY");
            Scanner scanner = new Scanner(System.in);
            SteppedArray stepped = new SteppedArray();
            
            System.out.println("Enter array size:");
            int size = scanner.nextInt();
            int[] arr = new int[size];
            System.out.println("Enter array elements:");
            
            for(int k = 0; k < size; k++) {
                arr[k] = scanner.nextInt();
            }
            
            int value = stepped.isStepped(arr);
            System.out.println("Is the array stepped? " + (value == 1 ? "Yes" : "No"));
        }
    }
    
    // Main menu
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        do {
            System.out.println("\n===== WORKSHEET PROGRAMS MENU =====");
            System.out.println(" 2. Question number 2");
            System.out.println(" 3. Question number 2 ");
            System.out.println(" 4. Question number 4 ");
            System.out.println(" 5. Question number 5 ");
            System.out.println(" 8. Question number 8 ");
            System.out.println(" 9. Question number 9 ");
            System.out.println("10. Question number 10 ");
            System.out.println("11. Question number 11 ");
            System.out.println("12. Question number 12 ");
            System.out.println("13. Question number 13 ");
            System.out.println("14. Question number 14 ");
            System.out.println("15. Question number 15 ");
            System.out.println("16. Question number 16 ");
            System.out.println(" 0. Exit");
            System.out.print("Enter your choice (question number): ");
            
            choice = scanner.nextInt();
            
            switch(choice) {
                case 2: TripleProduct.run(); break;
                case 3: SampleOutput.run(); break;
                case 4: ArrayOperations.run(); break;
                case 5: DoubleArrayOperations.run(); break;
                case 8: PlayerProgram.run(); break;
                case 9: CounterProgram.run(); break;
                case 10: CoinTossing.run(); break;
                case 11: EmployeeReport.run(); break;
                case 12: DiceGame.run(); break;
                case 13: FibonacciProgram.run(); break;
                case 14: PrimeHappyProgram.run(); break;
                case 15: ParitySumProgram.run(); break;
                case 16: SteppedArray.run(); break;
                case 0: System.out.println("Exiting program..."); break;
                default: System.out.println("Invalid choice! Please try again.");
            }
            
            if(choice != 0) {
                System.out.print("\nPress Enter to continue...");
                scanner.nextLine(); // Clear buffer
                scanner.nextLine(); // Wait for Enter
            }
        } while(choice != 0);
        
        scanner.close();
    }
}