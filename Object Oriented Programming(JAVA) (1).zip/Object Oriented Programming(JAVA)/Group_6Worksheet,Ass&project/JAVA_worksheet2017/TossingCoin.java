// Question number 10 from worksheet file.
package com.mycompany.tossingcoin;
import java.util.Random;
public class TossingCoin {
    int headCount;
    int tailCount;
      public TossingCoin(){
          this.headCount = 0;
          this.tailCount = 0;
      }
      public void getHeadCount(){
          headCount++;
      }
      public void getTailCount(){
          tailCount++;
      }
    public static void main(String[] args) {
                        System.out.println("QUESTION NUMBER 10 FROM WORKSHEET!");
        TossingCoin coin = new TossingCoin();
        Random random = new Random();
        for(int i = 1; i <= 100; i++){
            boolean isHead = random.nextBoolean();
            String result = isHead? "Head" : "Tail";
            if(result == "Head"){
                coin.getHeadCount();
            }else
                coin.getTailCount();
        }
        System.out.println("Total number of out as head : "+coin.headCount);
                System.out.println("Total number of out as tail : "+coin.tailCount);
    }
}
