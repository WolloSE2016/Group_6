/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dicegame;

public class DiceGame {
    // First version with public fields
    public static class PairOfDicePublic {
        public int die1;
        public int die2;
        
        public PairOfDicePublic() {
            roll();
        }
        
        public void roll() {
            die1 = (int)(Math.random() * 6) + 1;
            die2 = (int)(Math.random() * 6) + 1;
        }
        
        public int getTotal() {
            return die1 + die2;
        }
    }

    // Improved version with private fields
    public static class PairOfDicePrivate {
        private int die1;
        private int die2;
        private int rollCount;
        
        public PairOfDicePrivate() {
            roll();
        }
        
        public void roll() {
            die1 = (int)(Math.random() * 6) + 1;
            die2 = (int)(Math.random() * 6) + 1;
            rollCount++;
        }
        
        public int getDie1() { return die1; }
        public int getDie2() { return die2; }
        public int getTotal() { return die1 + die2; }
        public int getRollCount() { return rollCount; }
    }   

    public static void main(String[] args) {
                        System.out.println("QUESTION NUMBER 12 FROM WORKSHEET!");
        System.out.println("Testing Public Version:");
        testPublicVersion();
        
        System.out.println("\nTesting Private Version:");
        testPrivateVersion();
    }
    
    private static void testPublicVersion() {
        PairOfDicePublic dice = new PairOfDicePublic();
        int rolls = 1;
        
        while (dice.getTotal() != 2) {
            dice.roll();
            rolls++;
            System.out.printf("Roll %d: %d + %d = %d%n",
                            rolls, dice.die1, dice.die2, dice.getTotal());
        }
        System.out.println("Got snake eyes after " + rolls + " rolls!");
    }
    
    private static void testPrivateVersion() {
        PairOfDicePrivate dice = new PairOfDicePrivate();
        
        while (dice.getTotal() != 2) {
            dice.roll();
            System.out.printf("Roll %d: %d + %d = %d%n",
                           dice.getRollCount(),
                           dice.getDie1(),
                            dice.getDie2(),
                           dice.getTotal());
        }
        System.out.println("Got snake eyes after " + dice.getRollCount() + " rolls!");
    }
}