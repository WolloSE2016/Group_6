
package com.mycompany.fibonaci;
import java.util.Scanner;
public class Fibonaci {
    int[] arr;
    // Recursive method to calculate Fibonacci number
    public Fibonaci() {
        
    }
    
    int closestFibonacci(int n) {
        if (n < 1) {
            return 0;
        } else if (n > 0 && n <= 2) {
            return 1;
        } else {
            arr = new int[n + 2]; // Initialize array with enough size
            int max = 0;
  System.out.print("The fibonacci number under given number: " );
            for (int i = 1; i <= n; i++) {
                if (i == 1 || i == 2) {
                    arr[i] = 1;
                } else {
                    arr[i] = arr[i - 1] + arr[i - 2];
                }
                
                if (arr[i] > n) {
                    break; // Stop when we exceed n
                }
                max = arr[i]; // Update max with the current Fibonacci number
                System.out.printf( arr[i] + ", ");
            }
                            System.out.println(  "    ");

            return max;
        }
    }
    
    // Main method to test the function
    public static void main(String[] args) {
                        System.out.println("QUESTION NUMBER 13 FROM WORKSHEET!");
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the checking number :");
        int number = scanner.nextInt();
        Fibonaci fibonacci = new Fibonaci();
        int result = fibonacci.closestFibonacci(number);
        if( number > 2){
        System.out.println("The largest fibonacci number less than or equal to given number: " + result);
       
        }else if(number <= 2){
        System.out.println(result);
        }
    }
}