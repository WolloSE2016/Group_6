/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.largest;
import java.util.Scanner;
public class Largest {
    public Largest(){
        
    }
    public static int Return(int[] arr ){
        int large = arr[0];
        for(int t = 1; t <= arr.length - 1; t++){
        if(arr[t] > large)
            large = arr[t];
        }
        return large;
    } 
            public static int Return( int[][] twoDarr){
               int largest = twoDarr[0][0];
       for(int i =0; i < twoDarr.length; i++){
                  for(int j =0; j < twoDarr.length; j++){
                      if(twoDarr[i][j] > largest)
                         largest = twoDarr[i][j];
}
       }
                          return largest;
                  }
    

    public static void main(String[] args) {
                System.out.println("QUESTION NUMBER 4 FROM WORKSHEET!");
             System.out.println("ARRAY OF JAVA PROGRAM WITH SEARCHING INPUT FROM USER! ");
Scanner scanner = new Scanner(System.in);
Largest large = new Largest();
        System.out.println("size of 1D array!");
         int size, row, column ;
        size =scanner.nextInt();
                System.out.println("row size of 2D array!");
                row =scanner.nextInt();
                        System.out.println(" column size of 2D array!");

        column =scanner.nextInt();
        int[] sampleArray = new int[size];
                System.out.println("pls enter 1D array elements!");
        for(int k = 0; k < size; k++){
            sampleArray[k] = scanner.nextInt();
        }
int[][] twoD = new int[row][column];
                System.out.println("pls enter 2D array elements!");
for(int i = 0; i < row; i++){
    for(int j = 0; j < column; j++){
        twoD[i][j] = scanner.nextInt();
    }
}
       int max = Return(sampleArray );
               System.out.println("The largest value in 1D array "+ max );
               int result = Return(twoD );
               scanner.close();
    }
}
