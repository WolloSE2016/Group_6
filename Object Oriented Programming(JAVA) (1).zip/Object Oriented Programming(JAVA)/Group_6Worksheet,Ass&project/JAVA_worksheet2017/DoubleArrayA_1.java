/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.doublearraya;
import java.util.Scanner;
public class DoubleArrayA_1 {

    public static void main(String[] args) {
                    System.out.println("\nQUESTION NUMBER 5 FROM WORKSHEET - DOUBLING AN ARRAYs");
                        double[] A = new double[20];
        Scanner scanner = new Scanner(System.in);
        System.out.println("Pls enter 20 float numbers:");
                for(int i =0; i < 20;i++){
                    A[i] =scanner.nextDouble();
                }
      scanner.close();
    
    System.out.println("initial array values :");
    displayingArray(A);
    double Average = calculateAverage(A);
    System.out.println("average of values in the array  : "+Average);
    int Count = countingArray(A);
    System.out.println("total numbers of non-zero values  :  "+Count);
    }
    public static void displayingArray(double[] A){
        System.out.println("Elements"+" "+ "values");
        for(int i = 0; i < A.length; i++){
            System.out.println((i+1)+"   :   "+ A[i]);
        }
    }
        public static double calculateAverage(double[] A){
            double sum = 0.0;
            double average =0.0;
            for(int i = 0; i < A.length;i++){
                if(A[i]!=0){
                sum+=A[i];
            }
            }
            average = sum/A.length;
        return average;
        }
        public static int countingArray(double[] A){
            int count = 0;
            for(int i =0; i < A.length;i++){
                if(A[i]!=0){
                    count++;
                }
            }
            return count;
        }
    }

